# gemini_service.py

import os
import logging
from dotenv import load_dotenv
from google import genai
from prompt import SYSTEM_PROMPT

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env")

logging.basicConfig(level=logging.INFO)

class GeminiService:
    def __init__(self):
        self.client = genai.Client(api_key=API_KEY)

    def generate_response(self, user_input, chat_history):
        try:
            prompt = SYSTEM_PROMPT + "\nConversation:\n"
            for msg in chat_history:
                prompt += f"{msg['role']}: {msg['content']}\n"
            prompt += f"User: {user_input}\nAssistant:"

            response = self.client.models.generate_content(
                model="models/gemini-2.5-flash",  
                contents=prompt
            )

            return response.text

        except Exception as e:
            logging.error(f"Gemini API error: {e}")
            return "Something went wrong — please try again."