import streamlit as st
from gemini_service import GeminiService

st.set_page_config(page_title="Career Guru Chatbot", page_icon="🎓")
st.title("🎓 Career Guru Chatbot")
st.write("Welcome! Ask about your career goals below 👇")

service = GeminiService()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Display previous chat messages
for msg in st.session_state.chat_history:
    role = "user" if msg["role"] == "User" else "assistant"
    with st.chat_message(role):
        st.write(msg["content"])

user_input = st.chat_input("Ask about your career...")

if user_input:
    st.session_state.chat_history.append({"role": "User", "content": user_input})
    with st.chat_message("user"):
        st.write(user_input)

    with st.spinner("Thinking..."):
        answer = service.generate_response(user_input, st.session_state.chat_history)

    st.session_state.chat_history.append({"role": "Assistant", "content": answer})
    with st.chat_message("assistant"):
        st.write(answer)

# Clear chat button
if st.button("Clear Chat"):
    st.session_state.chat_history = []
    st.write("Chat cleared! Start a new conversation ")