import streamlit as st
import joblib
import re

model = joblib.load("model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

st.title("Flipkart Review Sentiment Analysis")

review = st.text_area("Enter Customer Review")

if st.button("Predict Sentiment"):
    clean_review = re.sub(r"[^a-z]", " ", review.lower())
    vector = vectorizer.transform([clean_review])
    prediction = model.predict(vector)

    if prediction[0] == 1:
        st.success("Positive Review")
    else:
        st.error("Negative Review ")