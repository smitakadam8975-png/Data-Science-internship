import pandas as pd
import re
import nltk
import joblib

from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

nltk.download("stopwords")
nltk.download("wordnet")


badminton = pd.read_csv(r"C:\flipkart_sentiment_project\data\reviews_badminton\data.csv")
tawa = pd.read_csv(r"C:\flipkart_sentiment_project\data\reviews_tawa\data.csv")
tea = pd.read_csv(r"C:\flipkart_sentiment_project\data\reviews_tea\data.csv")

# Remove extra spaces from column names
for df in [badminton, tawa, tea]:
    df.columns = df.columns.str.strip()

# Print column names to see actual names
print("Badminton columns:", badminton.columns)
print("Tawa columns:", tawa.columns)
print("Tea columns:", tea.columns)

badminton = badminton.rename(columns={'Ratings': 'Rating', 'Review text': 'Review'})
tawa = tawa.rename(columns={'Reviewer_Rating': 'Rating', 'Review_Text': 'Review'})
tea = tea.rename(columns={'reviewer_rating': 'Rating', 'review_text': 'Review'})

badminton["product"] = "badminton"
tawa["product"] = "tawa"
tea["product"] = "tea"

df = pd.concat([badminton, tawa, tea])
df.reset_index(drop=True, inplace=True)


df["sentiment"] = df["Rating"].apply(lambda x: 1 if x >= 4 else 0)

print(df.head())
print(df["sentiment"].value_counts())

stop_words = set(stopwords.words("english"))
lemmatizer = WordNetLemmatizer()

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"[^a-z]", " ", text)
    words = text.split()
    words = [lemmatizer.lemmatize(w) for w in words if w not in stop_words]
    return " ".join(words)

df["clean_review"] = df["Review"].apply(clean_text)



vectorizer = TfidfVectorizer(max_features=5000)
X = vectorizer.fit_transform(df["clean_review"])
y = df["sentiment"]


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LogisticRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print("F1 Score:", f1_score(y_test, y_pred))


joblib.dump(model, "model.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")

print("Model saved successfully!")

print("\nTop pain points from negative reviews:\n")
print(
    df[df["sentiment"] == 0]["clean_review"]
    .str.split().explode().value_counts().head(15)
)